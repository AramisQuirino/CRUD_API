﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace CRUD.Migrations
{
    public partial class MigracionInicial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Recibos",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    ReciboId = table.Column<int>(nullable: false),
                    Proveedor = table.Column<string>(maxLength: 50, nullable: false),
                    Monto = table.Column<double>(nullable: false),
                    Moneda = table.Column<string>(nullable: false),
                    Fecha = table.Column<DateTime>(nullable: false),
                    Comentario = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Recibos", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "Recibos",
                columns: new[] { "Id", "Comentario", "Fecha", "Moneda", "Monto", "Proveedor", "ReciboId" },
                values: new object[,]
                {
                    { new Guid("a87c9ddf-1bc9-4a88-87a5-8c5e716a06e0"), "", new DateTime(2020, 1, 10, 0, 0, 0, 0, DateTimeKind.Local), "Pesos", 3645.0, "Ruby", 1 },
                    { new Guid("d86ece69-6630-4639-82eb-d8250ce8ecc8"), "", new DateTime(2020, 1, 10, 0, 0, 0, 0, DateTimeKind.Local), "Pesos", 365.0, "Ruby1", 2 },
                    { new Guid("d68ed600-6b44-43e3-b08e-a2aacdc2589a"), "", new DateTime(2020, 1, 10, 0, 0, 0, 0, DateTimeKind.Local), "Pesos", 345.0, "Ruby2", 3 },
                    { new Guid("420717db-f1fd-4636-ae89-d59bb46ebc60"), "", new DateTime(2020, 1, 10, 0, 0, 0, 0, DateTimeKind.Local), "Pesos", 645.0, "Ruby3", 4 }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Recibos");
        }
    }
}
