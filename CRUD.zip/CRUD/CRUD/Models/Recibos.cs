﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CRUD.Models
{
    public class Recibos
    {
        public Recibos()
        {
            Id = Guid.NewGuid();
        }

        [Key]
        public Guid Id { get; set; }

        public int ReciboId { get;set; }

        [Required]
        [StringLength(50, MinimumLength = 3)]
        public string Proveedor { get; set; }

        [Required]
        public double Monto { get; set; }

        [Required]
        public string Moneda { get; set; }

        [Required]
        public DateTime Fecha { get; set; }

        public string Comentario { get; set; }
    }
}
