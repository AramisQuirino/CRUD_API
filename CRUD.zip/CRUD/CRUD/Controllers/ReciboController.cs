﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CRUD.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CRUD.Controllers
{
    [Route("api/[controller]")]
    [EnableCors]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class ReciboController : ControllerBase
    {
        private readonly ApplicationDbContext context;

        public ReciboController(ApplicationDbContext context)
        {
            this.context = context;
        }

        [EnableCors]
        [HttpGet]
        public IEnumerable<Recibos> GetRecibo()
        {
            return context.Recibos;
        }

        [HttpGet("{id}", Name = "ReciboCreado")]
        public IActionResult GetRecibo(int id)
        {
            var Recibo = context.Recibos.FirstOrDefault(x => x.ReciboId == id);

            if (Recibo == null)
            {
                return NotFound();
            }

            return Ok(Recibo);
        }

        [HttpPost]
        public IActionResult PostRecibo([FromBody] Recibos recibos)
        {
            if (ModelState.IsValid)
            {
                context.Recibos.Add(recibos);
                context.SaveChanges();

                return new CreatedAtRouteResult("ReciboCreado", new { id = recibos.ReciboId }, recibos);
            }

            return BadRequest(ModelState);
        }

        [HttpPut("{id}")]
        public IActionResult PutRecibo([FromBody] Recibos recibos, int id)
        {
            if (recibos.ReciboId != id)
            {
                return BadRequest();
            }

            context.Entry(recibos).State = EntityState.Modified;
            context.SaveChanges();

            return Ok();
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteRecibo(int id)
        {
            var recibo = context.Recibos.FirstOrDefault(x => x.ReciboId == id);

            if(recibo == null)
            {
                return NotFound();
            }

            context.Recibos.Remove(recibo);
            context.SaveChanges();
            return Ok(recibo);
        }
    }
}